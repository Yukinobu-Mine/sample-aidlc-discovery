# AI-DLC Discovery: Working Backwards

**Inputs.** Take each from the context so far, or ask:

- `{{project}}`: Project folder name under discovery/.
- `{{use_case}}`: The selected use case from use-case-scoring.md. With pods, each pod runs this skill for its own use case.
- `{{mode}}`: dialog (the team answers the five questions, then the PR/FAQ is written) or draft (write a straw-man PR/FAQ for the team to challenge, for example during a break). Ask the team if it is not given.

## Overview

Working Backwards writes the press release before anything is built: if the team cannot explain the customer benefit clearly enough to announce it, it should not build it. For the use case the team selected, this skill runs the five Working Backwards questions, writes the PR/FAQ and checks it is ready, writes the PRD, and ends by naming the riskiest assumption the prototype has to test. The team writes or challenges every document.

## Workflow

### Step 1: The five questions
- **Mode**: `agentic`
- **Input**: `{{use_case}}`, the Signal Analysis Report, the personas, `use-case-scoring.md`
- **Output**: `discovery/{{project}}/working-backwards/working-backwards.md`
- **Validate**: All five questions answered, in the team's words, with evidence where it exists
- **On failure**: If the team is stuck on a question, offer two suggestions from the signals and let it choose or rewrite

If the mode is not given, ask the team first, as one question in the round format: answer the five questions together, then write the PR/FAQ (`dialog`), or have a straw-man PR/FAQ drafted to challenge (`draft`)? Recommend `draft`, so the team can take a break while the straw-man is written and come back to a draft to challenge. In unattended runs, use `draft` without asking, and continue to Step 4 without waiting for the team.

Follow `modules/discovery-working-backwards/references/wb-document.md`: Listen, Define, Invent, Refine, Test. Ask one Working Backwards question per round: its parts are the round's questions, each with a recommended answer drafted from the signals and personas, so the team can accept with "yes" and correct the rest. Summarize each answer in at most three lines before the next round. Look up any fact the round needs in the data yourself (for example, which field values fail) instead of asking the team. The answers are the team's. In Listen and Define, apply `modules/discovery-working-backwards/references/framing-rules.md`: name the end customer, write root causes as causes, split the impact, and write the Today statement, How Might We, and North Star.

In `draft` mode, answer the five questions yourself from the morning's artifacts, write the PR/FAQ (Step 3), and mark the document as a straw-man. When the team returns, go through each answer with it before Step 4.

### Step 2: Feature description
- **Mode**: `agentic`
- **Input**: The Working Backwards document
- **Output**: `discovery/{{project}}/working-backwards/feature-description.md`
- **Validate**: The team chose one feature idea
- **On failure**: None

Follow `modules/discovery-working-backwards/references/feature-description.md`: propose 3 to 5 feature ideas for the problem, and let the team choose or combine them.

### Step 3: PR/FAQ
- **Mode**: `agentic`
- **Tool**: `file_write`
- **Input**: The Working Backwards document, the feature description, the personas
- **Output**: `discovery/{{project}}/working-backwards/prfaq.md`
- **Validate**: The press release has a headline, a subheading, and exactly seven paragraphs, each doing its one job, in 500 to 700 words; every claim in the FAQ carries an evidence label, and the press release labels only Assumed and Needs evidence claims; `modules/discovery-working-backwards/references/writing-audit.md` passes
- **On failure**: If a quality check fails, show the team which one and rewrite that part with it

Follow `modules/discovery-working-backwards/references/prfaq-generation.md`: customer thinking, the seven-paragraph press release, five to seven customer FAQs, and five to seven internal FAQs. The testimonial comes from a persona and is labeled as synthetic. Run `modules/discovery-working-backwards/references/writing-audit.md` before showing it, and say in one line what it checked and fixed.

Then ask the team to read the press release aloud and change anything that does not sound like it. This is where the team takes ownership of the document.

### Step 4: Readiness check
- **Mode**: `agentic`
- **Input**: `prfaq.md`
- **Output**: The verdict and the Prototype scope section, appended to `prfaq.md`
- **Validate**: All seven questions have a drafted answer or a marked gap; the verdict is GREEN, AMBER, or RED
- **On failure**: On RED, iterate on the PR/FAQ with the team before the prototype; on AMBER, carry the gaps as open hypotheses

Follow `modules/discovery-working-backwards/references/readiness-check.md`.

### Step 5: PRD
- **Mode**: `agentic`
- **Tool**: `file_write`
- **Input**: The PR/FAQ, the personas, the Signal Analysis Report, the scoring
- **Output**: `discovery/{{project}}/working-backwards/prd.md`
- **Validate**: P0, P1, and P2 requirements; P0 is small enough to prototype in an hour; when the feature uses AI, the AI feature checklist and the AI feature block are filled in
- **On failure**: If P0 is too big, ask the team what to move to P1

Follow `modules/discovery-working-backwards/references/prd-generation.md`, then run `modules/discovery-working-backwards/references/writing-audit.md` on it. When the feature uses AI (a model generates, ranks, summarizes, or decides something the customer sees), add the **AI feature block** with `modules/discovery-working-backwards/references/ai-feature-block.md`: a first-draft prompt, 5 to 10 evaluation cases from the Signals quotes and the personas, and sample outputs for the prototype. About 10 minutes with the team. If it is unclear whether the feature uses AI, ask.

### Step 6: Riskiest assumption
- **Mode**: `agentic`
- **Tool**: `file_write`
- **Input**: The PR/FAQ and the PRD, especially their Assumed and Needs evidence claims
- **Output**: `discovery/{{project}}/working-backwards/riskiest-assumption.md`
- **Validate**: One assumption, and what the prototype must show about it
- **On failure**: If the team names several, ask which one, if wrong, would end the idea

List the claims labeled Assumed or Needs evidence. Ask the team which one, if it turned out to be wrong, would end the idea. Write it down with what the prototype has to show to test it, and how the team will judge the result in Validate.

## Output

```markdown
# Riskiest assumption: [use case]

**Assumption:** [one sentence]
**Why it is the riskiest:** [what happens to the idea if it is wrong]
**What the prototype must show:** [the interaction or moment that tests it]
**How we will judge it in Validate:** [what would support it, what would contradict it]
```

The other outputs are the Working Backwards document, the feature description, the PR/FAQ with its readiness check, and the PRD, all under `discovery/{{project}}/working-backwards/`.

## Lessons Learned

### Do
- Ask the five questions one per round, each part with a recommended answer.
- Keep the press release to one page, and lead with the customer outcome.
- Label every claim in the FAQ, and only Assumed and Needs evidence claims in the press release; the riskiest assumption comes from the Assumed ones.

### Don't
- Write architecture or technology choices into the PRD.
- Treat the persona quote as a customer quote.
- Let the PRD grow past what can be prototyped today.

### Common Failures
- **The press release describes technology.** Rewrite the first paragraph from the customer's side.
- **The team accepts the draft without changes.** Ask it to read the press release aloud and change what does not sound like it.
- **Every assumption looks risky.** Ask which one, if wrong, means nobody uses it.

### When to Ask the User
- The team's answers contradict the signals.
- The readiness check finds two or more gaps.
- The team cannot agree on the riskiest assumption.
